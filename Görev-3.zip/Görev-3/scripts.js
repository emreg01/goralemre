
const images = [
    'images/image6.jpg',
    'images/image2.jpg',
    'images/image3.jpg',
    'images/image4.jpg',
    'images/image5.jpg',
    'images/image7.jpg',
    'images/image8.jpg',
    'images/image9.jpg',
    'images/image10.jpg',
    'images/image11.jpg',
    'images/image12.jpg',

];


const imageGallery = document.getElementById('imageGallery');

images.forEach((imageUrl, index) => {
    const imageElement = document.createElement('img');
    imageElement.src = imageUrl;
    imageElement.classList.add('img-thumbnail', 'm-2');
    imageElement.setAttribute('data-toggle', 'modal');
    imageElement.setAttribute('data-target', '#imageModal');
    imageElement.setAttribute('data-index', index);
    imageElement.addEventListener('click', displayModal);
    imageGallery.appendChild(imageElement);
});


function displayModal(event) {
    const index = event.target.getAttribute('data-index');
    const modalImage = document.getElementById('modalImage');
    modalImage.src = images[index];
}
